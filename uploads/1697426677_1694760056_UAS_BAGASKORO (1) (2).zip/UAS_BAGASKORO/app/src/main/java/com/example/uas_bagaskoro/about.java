package com.example.uas_bagaskoro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
import android.view.View;
import android.widget.Button;

public class about extends AppCompatActivity {

    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        // Inisialisasi tombol
        btnBack = findViewById(R.id.buttonback);

        // Memberikan onClickListener ke tombol Dokter
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent untuk membuka halaman Dokter
                Intent intent = new Intent(about.this, home.class);
                startActivity(intent);
            }
        });
    }
}