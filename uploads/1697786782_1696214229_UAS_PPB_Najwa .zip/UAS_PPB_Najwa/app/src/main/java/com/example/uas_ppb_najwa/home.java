
package com.example.uas_ppb_najwa;

        import androidx.appcompat.app.AppCompatActivity;

        import android.os.Bundle;

        import android.content.Intent;
        import android.view.View;
        import android.widget.Button;

public class home extends AppCompatActivity {

    private Button btnDokter, btnPasien, btnInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Inisialisasi tombol
        btnDokter = findViewById(R.id.btnDokter);
        btnPasien = findViewById(R.id.btnPasien);
        btnInfo = findViewById(R.id.btnInfo);

        // Memberikan onClickListener ke tombol Dokter
        btnDokter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent untuk membuka halaman Dokter
                Intent intent = new Intent(home.this, dokter_tampil.class);
                startActivity(intent);
            }
        });

        // Memberikan onClickListener ke tombol Pasien
        btnPasien.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent untuk membuka halaman Pendaftaran Pasien
                Intent intent = new Intent(home.this, pendaftaran.class);
                startActivity(intent);
            }
        });

        // Memberikan onClickListener ke tombol Info
        btnInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent untuk membuka halaman About Us
                Intent intent = new Intent(home.this, aboutus.class);
                startActivity(intent);
            }
        });
    }
}
