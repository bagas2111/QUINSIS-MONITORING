package com.example.uas_ppb_najwa;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.example.uas_ppb_najwa.RequestHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class pendaftaran extends AppCompatActivity {

    private EditText editTextNamaPasien, editTextJenisKelamin, editTextTanggalLahir;
    private Spinner spinnerDokter;
    private Button buttonSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pendaftaran);

        editTextNamaPasien = findViewById(R.id.editNama);
        editTextJenisKelamin = findViewById(R.id.editJK);
        editTextTanggalLahir = findViewById(R.id.editDOB);
        spinnerDokter = findViewById(R.id.spinnerDokter);
        buttonSubmit = findViewById(R.id.btnsubmit);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addDataToDatabase();
            }
        });

        // Mendapatkan data dokter dari database
        getDokterData();
    }

    private void getDokterData() {
        class GetDokterData extends AsyncTask<Void, Void, String> {
            @Override
            protected String doInBackground(Void... voids) {
                // Membuat instance dari RequestHandler
                RequestHandler requestHandler = new RequestHandler();

                // Mengirim permintaan GET untuk mendapatkan data dokter
                return requestHandler.sendGetRequest(konfigurasi.URL_GET_DOKTER);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);

                // Mengolah data dokter yang diterima
                if (s != null) {
                    try {
                        JSONArray jsonArray = new JSONArray(s);

                        // Membuat list untuk menyimpan objek Dokter
                        List<Dokter> dokterList = new ArrayList<>();

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);

                            // Mendapatkan data id dan nama dokter
                            String id = obj.getString("id");
                            String nama = obj.getString("nama_dokter");

                            // Membuat objek Dokter dan menambahkannya ke list dokterList
                            Dokter dokter = new Dokter(id, nama);
                            dokterList.add(dokter);
                        }

                        // Mengisi spinner dengan data dokterList
                        ArrayAdapter<Dokter> adapter = new ArrayAdapter<>(pendaftaran.this,
                                android.R.layout.simple_spinner_item, dokterList);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinnerDokter.setAdapter(adapter);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        GetDokterData getDokterData = new GetDokterData();
        getDokterData.execute();
    }

    private void addDataToDatabase() {
        final String namaPasien = editTextNamaPasien.getText().toString().trim();
        final String jenisKelamin = editTextJenisKelamin.getText().toString().trim();
        final String tanggalLahir = editTextTanggalLahir.getText().toString().trim();
        final String idDokter = ((Dokter) spinnerDokter.getSelectedItem()).getId();

        class AddData extends AsyncTask<Void, Void, String> {
            @Override
            protected String doInBackground(Void... voids) {
                // Membuat instance dari RequestHandler
                RequestHandler requestHandler = new RequestHandler();

                // Membuat data yang akan dikirim ke server
                String postData = konfigurasi.KEY_NAMA_PASIEN + "=" + namaPasien + "&" +
                        konfigurasi.KEY_JENIS_KELAMIN + "=" + jenisKelamin + "&" +
                        konfigurasi.KEY_TANGGAL_LAHIR + "=" + tanggalLahir + "&" +
                        konfigurasi.KEY_ID_DOKTER + "=" + idDokter;

                // Mengirim data ke server dan mendapatkan respons
                return requestHandler.sendPostRequest(konfigurasi.URL_ADD_DATA, postData);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                // Menampilkan respons dari server
                if (s != null) {
                    // Lakukan tindakan yang sesuai dengan respons dari server

                    // Mengarahkan ke MainActivity.java setelah data berhasil disimpan
                    Intent intent = new Intent(pendaftaran.this, home.class);
                    startActivity(intent);
                    finish();
                }
            }

        }

        AddData addData = new AddData();
        addData.execute();
    }

    public class Dokter {
        private String id;
        private String nama;

        public Dokter(String id, String nama) {
            this.id = id;
            this.nama = nama;
        }

        public String getId() {
            return id;
        }

        public String getNama() {
            return nama;
        }

        @Override
        public String toString() {
            return nama;
        }
    }
}
