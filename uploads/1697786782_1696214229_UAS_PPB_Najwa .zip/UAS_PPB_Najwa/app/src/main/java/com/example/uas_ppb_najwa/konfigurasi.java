package com.example.uas_ppb_najwa;

public class konfigurasi {
    public static final String URL_ADD_DATA = "http://172.20.10.3/UAS_PPB_el/tambahdokter.php";
    public static final String URL_GET_ALL_Doctor = "http://172.20.10.3/UAS_PPB_el/tampilSemuaDr.php";
    public static final String URL_GET_DOKTER = "http://172.20.10.3/UAS_PPB_el//dokter.php";
    // Dibawah ini merupakan Kunci yang akan digunakan untuk mengirim permintaan ke Skrip PHP
    public static final String KEY_EMP_ID = "id";
    public static final String KEY_EMP_NAMA_DOKTER = "namaDoktor";
    public static final String KEY_EMP_id_poli = "idPoli";
    public static final String KEY_EMP_FOTO_DOKTOR = "foto_doktor";
    public static final String KEY_PASIEN_NAMA = "namaPasien";
    public static final String KEY_PASIEN_UMUR = "namaPasien";
    public static final String KEY_PASIEN_DOKTER_ID = "namaPasien";

    // JSON Tags
    public static final String TAG_JSON_ARRAY = "result";
    public static final String TAG_ID = "id";
    public static final String TAG_NAMA_DOKTER = "nama_dokter";
    public static final String TAG_id_poli = "id_poli";
    public static final String TAG_FOTO_DOKTOR = "foto_doktor";
    public static final String KEY_NAMA_PASIEN = "nama_pasien";
    public static final String KEY_UMUR_PASIEN = "umur_pasien";
    public static final String KEY_JENIS_KELAMIN = "jenis_kelamin";
    public static final String KEY_TANGGAL_LAHIR = "tanggal_lahir";
    public static final String KEY_ID_DOKTER = "id_dokter";

    // ID karyawan
    // emp itu singkatan dari Employee
    public static final String DR_ID = "DR_id";
}
