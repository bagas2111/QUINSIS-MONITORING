package com.example.uas_ppb_najwa;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class dokter extends AppCompatActivity implements ListView.OnItemClickListener {

    private ListView listView;
    private String JSON_STRING;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dokter);
        listView = findViewById(R.id.listView);
        listView.setOnItemClickListener(this);
        getJSON();
    }

    private void showDoctor() {
        JSONObject jsonObject = null;
        ArrayList<HashMap<String, String>> list = new ArrayList<>();

        try {
            jsonObject = new JSONObject(JSON_STRING);
            JSONArray result = jsonObject.getJSONArray(konfigurasi.TAG_JSON_ARRAY);

            for (int i = 0; i < result.length(); i++) {
                JSONObject jo = result.getJSONObject(i);
                String id = jo.getString(konfigurasi.TAG_ID);
                String namaDokter = jo.getString(konfigurasi.TAG_NAMA_DOKTER);
                String idPoli = jo.getString(konfigurasi.TAG_id_poli);

                HashMap<String, String> doctor = new HashMap<>();
                doctor.put(konfigurasi.TAG_ID, id);
                doctor.put(konfigurasi.TAG_NAMA_DOKTER, namaDokter);
                doctor.put(konfigurasi.TAG_id_poli, idPoli);

                list.add(doctor);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        ListAdapter adapter = new SimpleAdapter(
                dokter.this, list, R.layout.list_item,
                new String[]{konfigurasi.TAG_ID, konfigurasi.TAG_NAMA_DOKTER, konfigurasi.TAG_id_poli},
                new int[]{R.id.id, R.id.nama_dokter, R.id.id_poli});

        listView.setAdapter(adapter);
    }

    private void getJSON() {
        class GetJSON extends AsyncTask<Void, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(dokter.this, "Mengambil Data", "Mohon Tunggu...", false, false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                JSON_STRING = s;
                showDoctor();
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequest(konfigurasi.URL_GET_ALL_Doctor);
                return s;
            }
        }

        GetJSON gj = new GetJSON();
        gj.execute();
    }

    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(this, dokter.class);
        HashMap<String, String> map = (HashMap<String, String>) parent.getItemAtPosition(position);
        String doctorId = map.get(konfigurasi.TAG_ID);
        intent.putExtra(konfigurasi.DR_ID, doctorId);
        startActivity(intent);
    }
}
